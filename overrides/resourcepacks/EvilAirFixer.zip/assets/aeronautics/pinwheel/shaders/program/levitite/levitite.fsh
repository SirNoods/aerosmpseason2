#include veil:fog
#include veil:color

uniform sampler2D Sampler0;
uniform sampler2D DiffuseDepthSampler;
uniform sampler2D Noise;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform mat4 ProjMat;
uniform vec2 ScreenSize;

uniform float time;
uniform int onSublevel;
uniform int layerIndex;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in float ghostLayerFullness;
in float ghostNoiseMagnitude;
in float depth;

out vec4 fragColor;

float linearizeDepth(float s) {
    // Same calculation mojang does, to linearize depths using the projection matrix values
    return -ProjMat[3].z /  (s * -2.0 + 1.0 - ProjMat[2].z);
}

vec3 getGhostColorHsv(vec3 hsv, bool forwards)
{
    hsv += forwards ? vec3(-0.45, 0, 0) : vec3(0.25, 0, 0);
    hsv.x = mod(hsv.x+1, 1);
    hsv.z = pow(hsv.z, 0.8);
    return hsv;
}

void main() {

}